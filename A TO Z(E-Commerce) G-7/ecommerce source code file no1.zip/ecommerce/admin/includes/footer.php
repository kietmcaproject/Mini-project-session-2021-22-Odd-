<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>All rights reserved</b>
    </div>
    <strong>Copyright &copy; 2021 Brought To You By<a href="https://kiet.edu/">MOHD RAGIB</a></strong>
</footer>