<html>
<head>
	<title>  
      	LOG IN | COLLEGE SPORTS MANAGEMENT
	</title>
	
    <style>
    p.serif {
  font-family: "Comic Sans MS", Times, serif;
  font-size: 2.5em; /* 40px/16=2.5em */
  color: #FF0000;
  font-weight: bold;
}


	</style>




</head>
<body style="background-image:url('ground.jpg');">
<table align="center" border="1" width="1290">
<tr>
<td height="300" width="200" bgcolor="#FF0000" COLSPAN="4" style="background-image:url(clipart-sporty-9.jpg);">
<marquee scrolldelay="100">
<body>

</body>

<p class="serif" >COLLEGE SPORTS MANAGEMENT TOOL</p>


</tr>

<tr>
<td width="100" align="center"><a href="index.html">HOME</A></td>
<td width="100" align="center"><a href="index.html">ABOUT US</A></td>
<td width="100" align="center"><a href="index.html">FEATURES</A></td>
<td width="100" align="center"><a href="index.html">HELP</A></td>
</tr>

<tr>
<td width="100" height="200" style="background-image:url('events.jpg');>
<MARQUEE DIRECTION="up" bgcolor="orange" SCROLLDELAY="200">

NEW FEEDS<BR>
NEW FEEDS<BR>
NEW FEEDS<BR>
NEW FEEDS<BR>
NEW FEEDS<BR>NEW FEEDS<BR>NEW FEEDS<BR>NEW FEEDS<BR>NEW FEEDS<BR>NEW FEEDS<BR>NEW FEEDS<BR>
</marquee></td>
<td width="100" bgcolor="orange" COLSPAN="3"><marquee direction="up" scrolldelay="200"><font size="5" color="brown" >The focus of this website to provide the sports teams a handy tool to manage their team players data , find new ways to improve their performances and take their game one level above the others.<br>
The sports teams can register themselves on our website and create profile for their players , our programme takes inputs of the athletes and based on the inputs given , the help is provided to the teams in terms of plans of workout sessions, injury management and workload management.</font></marquee></td>

</tr>






</table>
<form action="post.php" method="post" align=center>
			Enter Details: 
			<br>
			Name :
            <br>
			<input type = "text" placeholder = "Name" name = "name" required>
			<br>Dob
			<br>
			<input type = "date" placeholder = "DoB" name = "dob" required>
			<br>
			Gender
			<br>
			<input type = "text" placeholder = "Gender" name = "Gender" required>
			<br> 
			Phone no.
			<br>
			<input type = "text" placeholder = "Phone no." name = "Phone" required>
			<br> 
			Email
			<br>
			<input type = "text" placeholder = "Email" name = "Email" required>
			<br> 
			Name of sport
			<br>
			<input type = "text" placeholder = "Name of sport" name = "sport" required>
			<br>
			Name of club
			<br>
			<input type = "text" placeholder = "Name of club" name = "club" required>
			<br> 
            <br>
			Enter Username :
	            <br>
               		<input type = "text" placeholder = "Username" name = "usr" required>
			<br>
			<br>



			Enter Password :
	            <br>
               		<input type = "password" placeholder = "Password" name = "pwd" required>
			<br>
			<br>



                        Click Below To Sign In :
                  	<br>
                  	<input type = "SUBMIT" name= "signin" value ="Sign In" style="font-weight:bold">
			<br>
			<br>
			Reset The Fields : 
			<br>
			<input type = "RESET" value = "Reset" style="font-weight:bold">
			<br>
			<br>

			
			</form>


</body>
</html>
