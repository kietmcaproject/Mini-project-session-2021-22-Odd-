<html>
<title></title>
<head> <h1>WORKOUT ROUTINE SUGGESTOR</h1></head>
<body>
ENTER THE FOLLOWING DETAILS
<form method='POST'>
Enter the no of Endurance days
<input type="number" name="ed">
Enter the no of Endurance hours
<input type="number" name="eh">
<br>
Enter the no of Flexibility days
<input type="number" name="fd">
Enter the no of Flexibilty hours
<input type="number" name="fh">
<br>
Enter the no of Strength days
<input type="number" name="sd">
Enter the no of Strength hours
<input type="number" name="sh">
<br>
Age
<input type="nunmber" name="age">
<br>
<input type ="submit" value="SELECT" name="b1">


</form>
</body>
</html>

<?php
if(isset($_POST['b1']))
{
	$ed=$_POST['ed'];
	$fd=$_POST['fd'];
	$sd=$_POST['sd'];
	$eh=$_POST['eh'];
	$fh=$_POST['fh'];
	$sh=$_POST['sh'];
	$age=$_POST['age'];

	$favgWL=9.33;
	$savgWL=15.5;
	$tavgWL=19;

	$eWL=$ed*$eh*4;
	$fWL=$fd*$fh*2;
	$sWL=$sd*$sh*3;

	$avgWL=($eWL+$fWL+$sWL)/3;

//	$age_c=4;

//	if($age<15)
	//		$age_c=1;
//	}else
//	if ($age>=15 && $age<=24)
//	{
//	    $age_c=2;
 //    }else $age_c=3;


switch ($age)
{
	case "14": if($avgWL>(1.1*$favgWL) || $avgWL<(0.8*$favgWL) )
	{
		echo " Endurance hours=1.5 Endurance days=3 <br> Flexibility hours=1 Flexibilty days=2 <br> Strength hours=1 Strength days=2"; 
	}else 
	{
		echo "<br> Endurance hours=$eh Endurance days=$ed <br> Flexibility hours=$fh Flexibilty days=$fd <br> Strength hours=$sh Strength days=$sd";
	}  

	case "17":  if($avgWL>(1.1*$savgWL) || $avgWL<(0.8*$savgWL) )
	{
		echo "<br> Endurance hours=2 Endurance days=3 <br> Flexibility hours=1.5 Flexibilty days=3 <br> Strength hours=1.5 Strength days=3"; 
	}else 
	{
		echo " <br>Endurance hours=$eh Endurance days=$ed <br> Flexibility hours=$fh Flexibilty days=$fd <br> Strength hours=$sh Strength days=$sd";
	}  
	case "23" :  if($avgWL>(1.1*$tavgWL) || $avgWL<(0.8*$tavgWL) )
	{
		echo "<br> Endurance hours=2.5 Endurance days=3 <br> Flexibility hours=1.5 Flexibilty days=3 <br> Strength hours=2 Strength days=3"; 
	}else 
	{
		echo " <br>Endurance hours=$eh Endurance days=$ed <br> Flexibility hours=$fh Flexibilty days=$fd <br> Strength hours=$sh Strength days=$sd";
	}  
	default :  echo "<br> Endurance hours=$eh Endurance days=$ed <br> Flexibility hours=$fh Flexibilty days=$fd <br> Strength hours=$sh Strength days=$sd";
}
}
echo "<br>Inside wr suggestor";
?>
